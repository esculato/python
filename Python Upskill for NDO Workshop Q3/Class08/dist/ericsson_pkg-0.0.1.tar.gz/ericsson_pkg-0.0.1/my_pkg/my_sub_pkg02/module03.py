

def say_goodbye():
    print("Good bye!")
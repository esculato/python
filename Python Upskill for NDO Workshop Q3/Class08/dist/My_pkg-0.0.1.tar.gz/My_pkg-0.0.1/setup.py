from setuptools import setup, find_packages

setup(name='My_pkg',
      version='0.0.1',
      description = "This is my package",
      author = "Paul Kevin Rengifo Sandoval",
      author_email = "paul.rengifo.sandoval@ericsson.com",
      packages = find_packages(),
      install_requires=[
        'pyodbc'
    ]
)